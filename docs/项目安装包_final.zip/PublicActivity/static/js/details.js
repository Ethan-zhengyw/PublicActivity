function change_button1() {
		document.getElementById("button1_").innerHTML="已报名";
		document.getElementById("a-c-l-h-button1").style.backgroundColor="#d0d0d0";
	}
function change_button2() {
	document.getElementById("button2_").innerHTML="已关注";
	document.getElementById("a-c-l-h-button2").style.backgroundColor="#d0d0d0";
	}